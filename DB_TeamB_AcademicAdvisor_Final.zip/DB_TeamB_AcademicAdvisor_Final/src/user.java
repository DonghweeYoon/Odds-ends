import java.sql.*;
import java.util.*;


public class user {
	
	private PreparedStatement ps;
	private Statement s;

	private Connection con;
	
	
	
	public void UserRun() {

		con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			con = DriverManager.getConnection("jdbc:mysql://peace.handong.edu:3306/21400850_YoonaKim", "db21400850",
					"21400850");
			s = con.createStatement();

			 
			if (!con.isClosed()) {
	            Scanner scan = new Scanner(System.in);
	            System.out.println("Welcome to Academic Advisor!");
	            for (;;) {
	            	
	               System.out.println("\n Type 1 for University Search \n" + " Type 2 to retrieve top 10 Ranking \n"
	                     + " Type 3 to make your own ranking\n quit to End the program");
	               System.out.print(">> ");
	               
	               String inputLine = scan.nextLine();
	               inputLine = inputLine.toLowerCase();
	               String[] splitLine = inputLine.split(" ");

	               if (splitLine[0].equals("1")) {
	                  Search(); 
					} else if (splitLine[0].equals("2") ) {
						// retrieve top 10   
						System.out.println("Here is the top 10 Universities");
						UserFixRank(); 
														
					} else if (splitLine[0].equals("3") ) {
						// own ranking 
						try {
							calculateUserRank();
						} catch (Exception e){
							System.out.println("Syntax Error");
							continue; 
						}
					} else if (splitLine[0].equals("quit")) {
						break;
					} else {
						System.out.println("Wrong Command! ");
					}
			}
		}
		
		} catch (Exception e) {
			System.err.println("Exception: " + e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
	}
	
	public void Search() throws SQLException {
		

        System.out.println("insert command: ");
        System.out.println("   Name <university name> <location>");
        System.out.println("   Major <Major name>");
        System.out.println("   Location <location of the university>");
        System.out.println("   Tuition <max tuition>");
        System.out.println("   Student_number <max student number>");

        boolean check = false;
        
        Scanner scann = new Scanner(System.in);
        
        String inputLine; 
        String[] splitLine; 
        
        while (!check) {
           System.out.print(">> ");
           inputLine = scann.nextLine();
           inputLine = inputLine.toLowerCase();
           splitLine = inputLine.split(" ");

           if (splitLine[0].equals("name") && splitLine.length == 3) {
              String name = splitLine[1];
              String location = splitLine[2];

              ps = con.prepareStatement("SELECT * FROM university where UName = ? AND ULocation = ?");
              ps.setString(1, name);
              ps.setString(2, location);
              ps.executeQuery();
              ResultSet rs = ps.getResultSet();

              ResultSetMetaData meta = rs.getMetaData();

              if (rs.first()) {
               
                 for (int i = 1; i <= 8; i++) {
                    System.out.println(meta.getColumnName(i) + ": " + rs.getString(i));
                 }
              } else {
                 System.out.println(
                       "Data for " + name + " located in " + location + " does not exist.");
              }
              check = true;
           }

           else if (splitLine[0].equals("location") && splitLine.length == 2) {

              String location = splitLine[1];

              ps = con.prepareStatement("SELECT * FROM university where ULocation = ?");
              ps.setString(1, location);
              ps.executeQuery();
              ResultSet rs = ps.getResultSet();

              if (rs.next()) {
                 System.out.println("name: " + rs.getString(1));
                 while (rs.next())
                    System.out.println("name: " + rs.getString(1));
              } else {
                 System.out.println("There is no university located in " + location);
              }
              check = true;
           }
           else if (splitLine[0].equals("major") && splitLine.length == 2) {

               String majorTitle = splitLine[1];

               ps = con.prepareStatement("SELECT * FROM major where MajorTitle = ?");
               ps.setString(1, majorTitle);
               ps.executeQuery();
               ResultSet rs = ps.getResultSet();

               if (rs.next()) {
                  System.out.println("name: " + rs.getString(1));
                  while (rs.next())
                     System.out.println("name: " + rs.getString(1));
               } else {
                  System.out.println("There are no universities with that major " + majorTitle + ". \n");
               }
               check = true;
            }
           else if (splitLine[0].equals("tuition") && splitLine.length == 2) {
              // give table
              boolean numcheck = false;

              while (!numcheck) {
                 if (splitLine[1].matches("\\-?\\d+"))
                    numcheck = true;
                 else {
                    System.out.println("Enter max tuition again. Only integer values are allowed.");
                    System.out.print(">> ");
                    splitLine[1] = scann.nextLine();
                 }
              }

              // numcheck done.
              int tuition = Integer.parseInt(splitLine[1]);

              ps = con.prepareStatement("SELECT * FROM university where tuition <= ?");
              ps.setInt(1, tuition);
              ps.executeQuery();
              ResultSet rs = ps.getResultSet();

              if (rs.next()) {
                 System.out.println("name: " + rs.getString(1));
                 while (rs.next())
                    System.out.println("name: " + rs.getString(1));
              } else {
                 System.out.println("There is no university of under $" + tuition +" ");
              }
              check = true;
           }

           else if (splitLine[0].equals("student_number") && splitLine.length == 2) {
              boolean numcheck = false;

              while (!numcheck) {
                 if (splitLine[1].matches("\\-?\\d+"))
                    numcheck = true;
                 else {
                    System.out.println("Enter max student number again. Only integer values are allowed.");
                    System.out.print(">> ");
                    splitLine[1] = scann.nextLine();
                 }
              }

              // numcheck done.
              int studentnumber = Integer.parseInt(splitLine[1]);

              ps = con.prepareStatement("SELECT * FROM university where noStudent <= ?");
              ps.setInt(1, studentnumber);
              ps.executeQuery();
              ResultSet rs = ps.getResultSet();

              if (rs.next()) {
                 System.out.println("name: " + rs.getString(1));
                 while (rs.next())
                    System.out.println("name: " + rs.getString(1));
              } else {
                 System.out.println("There is no university with the student number less than " + studentnumber);
              }
              check = true;
           }

           else {
              System.out.println("Wrong input. Try again");
           }
        }		
	}
	
	public void UserFixRank() throws SQLException {
		
		int numberOfTop = 10;
		//read the university
		ps = con.prepareStatement("SELECT * FROM university Order by  rank  ASC;");//
		try {
			ps.executeQuery();
		}
		catch(Exception e){
			con.rollback();
			con.setAutoCommit(true);
			throw e;//terminate
		}
		//print the message
		ResultSet rs  = ps.getResultSet();//rank list
		int rank = 1;
		System.out.println("rank\tUname\tULocaton");
		while(rs.next()&&rank++<=numberOfTop){
			String b = rs.getString("rank");
			if(b == null){
				
			} else 
				System.out.println(rs.getString("rank")+"\t"+rs.getString("Uname") +"\t"+ rs.getString("ULocation"));
		}
		rs.close();//finish the result set
	}
	
	
	
	public void calculateUserRank() throws SQLException {
		con.setAutoCommit(false);
		
		String crietria[] = {"Graduation and Retention Rate ", "Entering Classes' scores ", "Faculty Quality ", "Finanical Aid ", "graduates' performance ", "environment "}; 
		
		System.out.println("You have chosen 'make your own ranking'");
		System.out.println(" to do so, you can set your own weights ");
		System.out.println(" default weights of grading crierias are: ");

		double[] deweight = {0.2, 0.15, 0.15, 0.15, 0.2, 0.15};
		
		for (int i = 0; i < deweight.length; i++) 
			System.out.println(String.format("%-33s :  %-10s",crietria[i],deweight[i]));
		
		System.out.println();
		
		int weightLength = 6;
		double[] weight = new double [weightLength];
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println(" Enter your own weights ");
		for (int i = 0; i < weightLength; i++) {
			System.out.print(crietria[i] + ": ");
			
			try {
				weight[i] = scan.nextDouble();
				
			} catch (Exception e) {
				System.out.println("Please enter only number");
				throw e; 
			}
		}
		
        
        int numberOfTop = 10;

        //error check
        if(weight.length != weightLength) {
            System.out.println("The number of weight should be " + weightLength);
            con.rollback();
            con.setAutoCommit(true);
            throw new EmptyStackException();
        }

        //sum of weight should be 1
        double sum = 0;
        for(int i=0; i<weightLength; i++){
            sum +=weight[i];
        }
        if(sum < 0.999999 || sum  > 1.0000001){
            System.out.println("The sum of all weights should be 1");
            con.rollback();
            con.setAutoCommit(true);
            throw new EmptyStackException();
        }

        //read the uGrade rank
        ps = con.prepareStatement("SELECT * FROM uGrade Order by  GRR * ? + EnteringClass * ? + Faculty * ? + Finance * ? + graduate * ? + environment * ?  DESC");
        for(int i=0; i<weightLength; i++) {
            ps.setDouble(i+1, weight[i]);
        }
        try {
            ps.executeQuery();
        }
        catch(Exception e){
            con.rollback();
            con.setAutoCommit(true);
            throw e;//terminate
        }

        //make the message
        ResultSet rs  = ps.getResultSet();//rank list
        String [] message = new String [numberOfTop];
        int rank = 0;
        ResultSet universityRs = null;
        while(rs.next()&&rank<message.length){
            ps = con.prepareStatement(
                    "SELECT * FROM university WHERE UName = ? AND ULocation = ?;");
            ps.setString(1, rs.getString("UName"));
            ps.setString(2, rs.getString("Ulocation"));
            try {
                ps.executeQuery();
                universityRs = ps.getResultSet();//get result set
                if(!universityRs.next())
                    throw new EmptyStackException();
                message[rank] = String.format("%-15s %-15s %s", universityRs.getString("Uname"), universityRs.getString("ULocation"), universityRs.getString("overview"));
            }catch(Exception e){
                System.out.println("Fail to get the University information.");
                con.rollback();
                con.setAutoCommit(true);
                throw e;
            }
            rank++;//start from 1
            universityRs.close();//close result set
        }
        rs.close();//finish the result set

        //message print
        System.out.println("--------------------------------------------------------------------------------------------------------------");

        System.out.println( String.format("%-4s %-15s %-15s %s", "Rank", "university name", "Location", "Overview"));//title
        System.out.println("--------------------------------------------------------------------------------------------------------------");
        for(int i=0;(i<message.length)&&(i<rank);i++)
            System.out.println(String.format("%-2d   ", (i+1)) + message[i]);
    }
	
}
