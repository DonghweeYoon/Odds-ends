
import java.sql.*;
import java.util.*;

public class AcademicAdvisor {

	public static void main(String[] args) {

		Connection con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			con = DriverManager.getConnection("jdbc:mysql://peace.handong.edu:3306/21400850_YoonaKim", "db21400850",
					"21400850");

			if (!con.isClosed()) {
				for (int i = 0; i < 3; i++)
					System.out.print("*****************************");
				System.out.println();
				System.out.println("Welcome to Academic Advisor (type 1 if you are a user/ Type 2 if you are a Admin)");
				System.out.println("(type 1 if you are a user/ Type 2 if you are a Admin)");
				for (int i = 0; i < 3; i++)
					System.out.print("*****************************");
				System.out.println();
			}

			// creates necessary tables for the application at start if the
			// table is not defined in the database

			Statement s = con.createStatement();
			s.executeUpdate(
					"CREATE TABLE IF NOT EXISTS admin (AdminCode CHAR(50), password int, PRIMARY KEY(AdminCode))");

/*			 s.executeUpdate("DROP TABLE IF EXISTS major");
			s.executeUpdate("DROP TABLE IF EXISTS uGrade");
			 s.executeUpdate("DROP TABLE IF EXISTS university");
*/
			s.executeUpdate(
					"CREATE TABLE IF NOT EXISTS university(UName CHAR(100), ULocation CHAR(100), overview CHAR(255), "
							+ "tuition int, GRR decimal(4,1), AAG decimal(2,1), noStudent int, Rank int, PRIMARY KEY(UName, ULocation))");

			s.executeUpdate("CREATE TABLE IF NOT EXISTS major("
					+ "UName CHAR(100), ULocation CHAR(100), majorTitle CHAR(50), associate bool, BA bool, MA bool, PhD bool,"
					+ "PRIMARY KEY(majorTitle, UName, ULocation),"
					+ "FOREIGN KEY (UName, ULocation) REFERENCES university(UName, ULocation)"
					+ "ON UPDATE CASCADE ON DELETE CASCADE )");

			s.executeUpdate("CREATE TABLE IF NOT EXISTS uGrade("
					+ "UName CHAR(100), ULocation CHAR(100), GRR int, EnteringClass int, Faculty int, Finance int, graduate int, environment int, score decimal(4,1), "
					+ "PRIMARY KEY(UName, ULocation), "
					+ "FOREIGN KEY (UName, ULocation) REFERENCES university(UName, ULocation) ON UPDATE CASCADE ON DELETE CASCADE)");
			
/*******************************************************************************************************************************************/
			

			Scanner scan = new Scanner(System.in);
			String userGiven = "";
			boolean run = true;

			while (run) {
				userGiven = (scan.nextLine()).trim();

				if (userGiven.equals("1")) {
					user u = new user();
					u.UserRun();
					System.out.println("Bye~ Thanks for visiting Academic Advisor! \n");
					run = false;

				} else if (userGiven.equals("2")) {
					admin a = new admin();
					a.AdminRun();
					System.out.println("Admin terminate\n");
					run = false;

				} else
					System.out.println("Try again");
			}
			scan.close();

		} catch (Exception e) {
			System.err.println("Exception: " + e.getMessage());

		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
	}
}
