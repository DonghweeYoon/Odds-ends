import java.sql.*;
import java.util.Scanner;

public class Bookstore{
    public static void main(String args[]) {
        Connection conn = null;
        Scanner scan = new Scanner(System.in);

        try {
        	//connect to database
        	Class.forName("com.mysql.jdbc.Driver").newInstance() ;
            conn = DriverManager.getConnection("jdbc:mysql://peace.handong.edu:3306/21300482_YOONDONGHWEE", "db21300482", "21300482");
            if (!conn.isClosed())
            System.out.println("Successfully connected to MySQL server.");

            Statement fixedState = conn.createStatement();
            
            //create DB & trigger
            createDb_Trig(fixedState);
            
            //working loop
            for(;;){
            	String inputLine = scan.nextLine();
            	String[] splitLine = inputLine.split(" ");

            	if(splitLine[0].equals("stock")){
            		stock(fixedState, splitLine, conn);
            	}
             	else if(splitLine[0].equals("purchase")){
                	purchase(fixedState, splitLine, conn);
            	}	
             	else if(splitLine[0].equals("search")){
                	search(fixedState, splitLine, conn);
            	}
            	else if(splitLine[0].equals("report")){
                	report(fixedState, splitLine, conn);
            	}
            	else if(splitLine[0].equals("quit")){
            		fixedState.close();
            		System.out.println("System out!");
            		break;
            	}
            	else{
            		System.out.println("Invalid input, check the syntax");
            	}
            }
        }
        catch(Exception e) {
            System.err.println("Exception: " + e.getMessage());
        } 
        finally{
        	try {
        		if (conn != null)
        			conn.close();
        	} 
        	catch(SQLException e) {}
        }
    }
 
    public static void createDb_Trig(Statement fixedState) throws SQLException{
    	fixedState.execute(
        		"CREATE TABLE IF NOT EXISTS stock("
        		+ "title VARCHAR(64) not null,"
        		+ "author VARCHAR(64) not null,"
        		+ "category VARCHAR(32) not null default 'Misc.',"
        		+ "ISBN BIGINT,"
        		+ "copy INT default 1 CHECK (copy >= 0),"
        		+ "PRIMARY KEY(ISBN));");
       
        fixedState.execute(
        		"CREATE TABLE IF NOT EXISTS sold("
                + "custname VARCHAR(64),"
            	+ "ISBN BIGINT,"
            	+ "datesold DATE,"
            	+ "numsold INT default 1 CHECK (numsold >= 0),"
            	+ "PRIMARY KEY(ISBN, custname));");
        
    }
    public static void stock(Statement fixedState, String[] splitLine, Connection conn) throws SQLException{
		PreparedStatement freeState = null;
		ResultSet rs = null;
		
    	if(splitLine.length == 5){
			freeState = conn.prepareStatement(
				"SELECT ISBN FROM stock WHERE ISBN = ? AND "
				+ "(NOT (title = ? AND author = ? AND category = ?));"
			);
			freeState.setLong(1, Long.parseLong(splitLine[3]));
			freeState.setString(2, splitLine[1]);
			freeState.setString(3, splitLine[2]);
			freeState.setString(4, splitLine[4]);
        		
			freeState.executeQuery();
			rs = freeState.getResultSet();
			if(rs.first()){
				System.out.println("The book with same ISBN but different info exists");
			}
			else{
				freeState = conn.prepareStatement(
					"UPDATE stock"
					+ " SET copy = copy + 1"
					+ " WHERE (title = ? AND author = ? AND ISBN = ? AND category = ?);");
				freeState.setString(1, splitLine[1]);
				freeState.setString(2, splitLine[2]);
				freeState.setLong(3, Long.parseLong(splitLine[3]));
				freeState.setString(4, splitLine[4]);
				freeState.executeUpdate();
        		
				freeState = conn.prepareStatement(
               		"SELECT * FROM stock WHERE ISBN = ?;");
				freeState.setLong(1, Long.parseLong(splitLine[3]));
        		freeState.executeQuery();
        		rs = freeState.getResultSet();
              		
        		if(!(rs.first())){
        			freeState = conn.prepareStatement(
        				"INSERT INTO stock(title, author, ISBN, category) VALUES(?,?,?,?);");
        			freeState.setString(1, splitLine[1]);
        			freeState.setString(2, splitLine[2]);
        			freeState.setLong(3, Long.parseLong(splitLine[3]));
        			freeState.setString(4, splitLine[4]);
        			freeState.executeUpdate();
        		}
			}
			freeState.close();
			rs.close();
		}
		else if(splitLine.length == 4){
			freeState = conn.prepareStatement(
				"SELECT ISBN FROM stock WHERE ISBN = ? AND"
				+ " (NOT (title = ? AND author = ? AND category = 'Misc.'));"
			);
			freeState.setLong(1, Long.parseLong(splitLine[3]));
			freeState.setString(2, splitLine[1]);
			freeState.setString(3, splitLine[2]);
           		
			freeState.executeQuery();
			rs = freeState.getResultSet();
			if(rs.first()){
				System.out.println("The book with same ISBN but different info exists");
			}
			else{
				freeState = conn.prepareStatement(
					"UPDATE stock"
					+ " SET copy = copy + 1"
					+ " WHERE (title = ? AND author = ? AND ISBN = ? AND category = 'Misc.');");
				freeState.setString(1, splitLine[1]);
				freeState.setString(2, splitLine[2]);
				freeState.setLong(3, Long.parseLong(splitLine[3]));
				freeState.executeUpdate();
           		
				freeState = conn.prepareStatement(
					"SELECT ISBN FROM stock WHERE ISBN = ?;");
				freeState.setLong(1, Long.parseLong(splitLine[3]));
				freeState.executeQuery();
				rs = freeState.getResultSet();
          
				if(!(rs.first())){
					freeState = conn.prepareStatement(
						"INSERT INTO stock(title, author, ISBN) VALUES(?,?,?);" );
					freeState.setString(1, splitLine[1]);
					freeState.setString(2, splitLine[2]);
					freeState.setLong(3, Long.parseLong(splitLine[3]));
					freeState.executeUpdate();
				}
			}
			freeState.close();
			rs.close();		
    	}
    }
    
    public static void purchase(Statement fixedState, String[] splitLine, Connection conn) throws SQLException{
    		PreparedStatement freeState = null;
    		ResultSet rs = null;
    		
    		freeState = conn.prepareStatement(
    			"SELECT * FROM stock WHERE (ISBN = ? AND copy > 0);"
    		);
    		freeState.setString(1, splitLine[2]);
    			
    		freeState.executeQuery();
        	rs = freeState.getResultSet();
        	if(rs.first()){
        		try {
        			conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);

        			conn.setAutoCommit(false);
        			
        			freeState = conn.prepareStatement(
        				"SELECT * FROM sold WHERE custname = ? AND ISBN = ?;");
        			freeState.setString(1, splitLine[1]);
    				freeState.setLong(2, Long.parseLong(splitLine[2]));
        			freeState.executeQuery();
        			
        			rs = freeState.getResultSet();
                  
        			if(rs.first()){
        				freeState = conn.prepareStatement(
                				"UPDATE sold"
                				+ " SET numsold = numsold + 1"
                				+ " WHERE custname = ? AND ISBN = ?;");
                		freeState.setString(1, splitLine[1]);
                		freeState.setLong(2, Long.parseLong(splitLine[2]));
                		freeState.executeUpdate();	
        			}
        			else{
            			freeState = conn.prepareStatement(
            					"INSERT INTO sold(custname, ISBN, datesold) VALUES(?,?,CURDATE());");
            			freeState.setString(1, splitLine[1]);
            			freeState.setLong(2, Long.parseLong(splitLine[2]));
            			freeState.executeUpdate();
        			}
        			
        			freeState = conn.prepareStatement(
        				"UPDATE stock"
        				+ " SET copy = copy - 1"
        				+ " WHERE ISBN = ?;"
        			);
        			
        			freeState.setLong(1, Long.parseLong(splitLine[2]));
        			freeState.executeUpdate();
                    
        			conn.commit();                			
        			
        			rs.close();
        			freeState.close();
        		}
        		catch(SQLException e) {
            		e.printStackTrace();
            		if( conn != null ){
            			try {conn.rollback();}
            			catch(SQLException sqle) {}
            		}
            	}
    		}
        	else{
        		System.out.println("There is no book with such IBSN available");
        	}
    }
    
    public static void search(Statement fixedState, String[] splitLine, Connection conn) throws SQLException{
    	PreparedStatement freeState;
    	       
    	freeState = conn.prepareStatement(
           	"SELECT * FROM stock WHERE title LIKE ? OR author LIKE ?");	
        freeState.setString(1, "%" + splitLine[1] + "%");
        freeState.setString(2, "%" + splitLine[1] + "%");
            	
    	freeState.executeQuery();
    	ResultSet rs = freeState.getResultSet();
    	if(rs.first()){
    		do{
    			String sTitle = rs.getString("title");
    			String sAuthor = rs.getString("author");
    			String sCategory = rs.getString("category");
    			long sISBN = rs.getLong("ISBN");
    			int sCopy = rs.getInt("copy");
    			System.out.println("title = " + sTitle + ", author = " + sAuthor + ", category = "
    				+ sCategory + ", ISBN = " + sISBN + ", copy = " + sCopy);
    		}while(rs.next());
    		rs.close();
    		freeState.close();
    	}
    	else{
    		System.out.println("There is no book related to the keyword");
    	}
    }
    
    public static void report(Statement fixedState, String[] splitLine, Connection conn) throws SQLException{
    	fixedState.executeQuery("SELECT title, SUM(numsold)"
			+ " FROM"
			+ " (SELECT title, ISBN, custname, numsold"
			+ " FROM stock NATURAL JOIN sold"
			+ " WHERE datesold = CURDATE()) dailysold"
			+ " GROUP BY title"
			+ " ORDER BY SUM(numsold) DESC;");
		
		ResultSet rs = fixedState.getResultSet();
		
		if(rs.first()){
			do{
				String dTitle = rs.getString("title");
				int dSold = rs.getInt("SUM(numsold)");
				System.out.println("The book " + dTitle + " is sold " + dSold + " times today");
			}while(rs.next());
			rs.close();
		}
		else{
			System.out.println("There is no book sold today");
		}
    }
}