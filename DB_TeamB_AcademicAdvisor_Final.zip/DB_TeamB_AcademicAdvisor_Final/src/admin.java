
import java.sql.*;
import java.util.*;

public class admin {

	private PreparedStatement ps;
	private Statement s;

	private Connection con;

	public void AdminRun() {

		con = null;

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			con = DriverManager.getConnection("jdbc:mysql://peace.handong.edu:3306/21400850_YoonaKim", "db21400850",
					"21400850");

			s = con.createStatement();

			if (!con.isClosed()) {
				Boolean adminCheck = false;
				Scanner scan = new Scanner(System.in);
				// adminCheck
				while (!adminCheck) {
					System.out.println("Give AdminCode and password: ");

					String inputLine = scan.nextLine();
					String splitLine[] = inputLine.split(" ");
					if (splitLine.length == 2) {
						ps = con.prepareStatement("SELECT * FROM admin Where AdminCode= ? AND password = ?");
						ps.setString(1, splitLine[0]);
						ps.setString(2, splitLine[1]);
						ps.executeQuery();

						ResultSet rs = ps.getResultSet();

						if (rs.next())
							adminCheck = true;
						else
							System.out.println("Check your userCode or password");
					} else
						System.out.println("Syntax error");
				}

				System.out.println("Welcome to Admin space!"
						+ "\nInsert_U <name>,<location>\nInsert_M <name>,<location>,<major>\nInsert_G <name>,<location>"
						+ "\nDelete_U <name>,<location>\nDelete_M <name>,<location>,<major>\nDelete_G <name>,<location>"
						+ "\nEdit_U <name>,<location>,<Attribute>,<Value>\nEdit_M <name>,<location>,<major>,<Attribute>,<Value>"
						+ "\nEdit_G <name>,<location>,<Attribute>,<Value>\nCreateNewAdmin <AdminCode>,<password>\nquit"
						+ "\n");

				for (;;) {
					System.out.println("Insert Command");
					System.out.print(">>");
					String inputLine = scan.nextLine();
					inputLine = inputLine.toLowerCase();
					String[] splitLine = inputLine.split(" ");

					if (splitLine[0].equals("insert_u") && splitLine.length == 3) {

						// check if given name and location already exists
						ps = con.prepareStatement("SELECT * FROM university where UName = ? AND ULocation = ?");
						ps.setString(1, splitLine[1]);
						ps.setString(2, splitLine[2]);
						ps.executeQuery();

						ResultSet rs = ps.getResultSet();
						boolean newInfo = true;
						if (rs.first()) {
							newInfo = false;
							System.out.println("Given information already exist /n");
						}

						rs.close();

						if (newInfo) {
							// doesn't exist so enter all info.
							System.out.println(
									"enter tuition, GRR, AAG, noStudents (single space between each attribute)");
							String[] splitinfo = {};

							boolean dataCorrect = false;

							while (!dataCorrect) {
								System.out.print(">>");
								String inputinfo = scan.nextLine();
								splitinfo = inputinfo.split(" ");
								if (splitinfo.length != 4) {
									System.out.println("input syntax error, try again");
								} else {
									boolean numOk = true;
									for (int i = 0; i < 4; i++) {
										if (!splitinfo[i].matches("((-|\\+)?[0-9]+(\\.[0-9]+)?)+")) {
											System.out.println("invalid input, enter only numbers");
											numOk = false;
											break;
										}
									}
									if (numOk) {

										double gg = Double.parseDouble(splitinfo[1]);
										double aa = Double.parseDouble(splitinfo[2]);
										if ((gg >= 0 && gg <= 1) && (aa >= 0 && aa <= 4.5)) {
										} else {
											numOk = false;
											System.out.println("invalid input");
											break;
										}

									}
									if (numOk) {
										System.out.println("type the overview: ");
										System.out.print(">>");
										String inputoverview = scan.nextLine();
										ps = con.prepareStatement(
												"INSERT INTO university(UName, ULocation, overview, tuition, GRR, AAG, noStudent, Rank) VALUES(?,?,?,?,?,?,?,?)");
										ps.setString(1, splitLine[1]);
										ps.setString(2, splitLine[2]);
										ps.setString(3, inputoverview);
										ps.setString(4, splitinfo[0]);
										ps.setString(5, splitinfo[1]);
										ps.setString(6, splitinfo[2]);
										ps.setString(7, splitinfo[3]);
										ps.setString(8, null);
										ps.executeUpdate();

										dataCorrect = true;
										System.out.println("Successfully added " + splitLine[1] + " located in "
												+ splitLine[2] + " into university table.");

									}
								}
							}
						}
					} else if (splitLine[0].equals("insert_m") && splitLine.length == 4) {

						String targetUName = splitLine[1];
						String targetULocation = splitLine[2];
						String targetmajor = splitLine[3];

						ps = con.prepareStatement(
								"SELECT * FROM major where UName = ? AND ULocation = ? AND majorTitle = ?");
						ps.setString(1, targetUName);
						ps.setString(2, targetULocation);
						ps.setString(3, targetmajor);
						ps.executeQuery();
						ResultSet rs = ps.getResultSet();
						boolean exist = false;

						if (rs.first()) {
							exist = true;
							System.out.println(splitLine[1] + " located in " + splitLine[2] + " already has "
									+ splitLine[3] + " major in the major table.");
						}

						if (!exist) {
							ps = con.prepareStatement("SELECT * FROM university where UName = ? AND ULocation = ?");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeQuery();
							ResultSet rss = ps.getResultSet();

							if (!rss.first()) {
								System.out.println("Given university " + targetUName + " located in " + targetULocation
										+ " does not exist");
							} else {
								System.out.println(
										"Enter associate, BA, MA, PhD (single space between each attribute, enter \"T\" or \"F\")");

								System.out.print(">>");
								String inputinfo = "";
								String[] splitinfo = {};
								boolean pass = false;
								// length check
								while (splitinfo.length != 4 || !pass) {
									inputinfo = scan.nextLine();
									inputinfo = inputinfo.toUpperCase();
									splitinfo = inputinfo.split(" ");
									if (splitinfo.length == 4) {
										pass = true;
										for (int i = 0; i < 4; i++) {
											if (splitinfo[i].trim().equals("T") || splitinfo[i].trim().equals("F")) {

											} else {
												System.out.println(splitinfo[i] + " is an invalid input, try again");
												System.out.print(">>");
												pass = false;
												break;
											}
										}
									} else {
										System.out.print("Wrong input. type again.\n>> ");
									}
								}

								if (pass = true) {
									ps = con.prepareStatement(
											"INSERT INTO major(UName, ULocation, majorTitle, associate, BA, MA, PhD) VALUES(?,?,?,?,?,?,?)");
									ps.setString(1, splitLine[1]);
									ps.setString(2, splitLine[2]);
									ps.setString(3, splitLine[3]);
									for (int i = 0; i < 4; i++) {
										if (splitinfo[i].equals("T")) {
											// insert true
											ps.setBoolean(i + 4, true);
										} else {
											// insert false
											ps.setBoolean(i + 4, false);
										}
									}
									ps.executeUpdate();

									System.out.println("Successfully added " + splitLine[3] + " major into "
											+ splitLine[1] + " located in " + splitLine[2] + " into major table.");
								}

							}
						}
					} else if (splitLine[0].equals("insert_g") && splitLine.length == 3) {
						// insert allowed only if name and location exists in
						// university
						String targetUName = splitLine[1];
						String targetULocation = splitLine[2];

						boolean numOk = true;
						boolean successful = false;

						ps = con.prepareStatement("SELECT * FROM university where UName = ? AND ULocation = ? ");
						ps.setString(1, targetUName);
						ps.setString(2, targetULocation);
						ps.executeQuery();

						ResultSet rs = ps.getResultSet();

						con.setAutoCommit(false);

						if (rs.next()) {
							double[] weight = { 0.2, 0.15, 0.15, 0.15, 0.2, 0.15 };
							ps = con.prepareStatement("SELECT * FROM uGrade where UName = ? AND ULocation = ? ");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeQuery();
							ResultSet rss = ps.getResultSet();
							if (rss.next()) {
								System.out.println("Data already exist");

							} else {
								// doesn't exist so enter all info.

								String[] splitinfo = {};
								while (splitinfo.length != 6) {
									System.out.println(
											"enter GRR, EnterClass, Faculty, Finance, graduate, environment (single space between each attribute, should be 1 - 10)");
									System.out.print(">>");
									String inputinfo = scan.nextLine();
									splitinfo = inputinfo.split(" ");
								}

								int i = 0;
								double sum = 0;

								ps = con.prepareStatement(
										"INSERT INTO uGrade(UName, ULocation, GRR, EnteringClass, Faculty, Finance, graduate, environment, score) VALUES(?,?,?,?,?,?,?,?,?)");
								ps.setString(1, splitLine[1]);
								ps.setString(2, splitLine[2]);

								int cur = -10;

								for (i = 0; i < 6; i++) {
									cur = (int) Integer.parseInt(splitinfo[i]);
									ps.setInt(i + 3, (int) Integer.parseInt(splitinfo[i]));
									if (cur > 10)
										numOk = false;
									sum += (int) Integer.parseInt(splitinfo[i]) * weight[i];
								}

								sum *= 100;
								sum = Math.round(sum) * 0.01;
								ps.setDouble(i + 3, sum);
								ps.executeUpdate();
								if (numOk)
									successful = true;
							}
						} else {
							System.out.println("Given university does not exist in university table(list)");
						}
						rs.close();

						if (successful) {
							System.out.println("Insertion of " + targetUName + " located at " + targetULocation
									+ " was successful.\n");
							con.commit();
							calculateRank();
						} else {
							System.out.println(
									"Could not add grade to " + targetUName + " located at " + targetULocation + "\n");
							con.rollback();
						}
						con.setAutoCommit(true);

					} else if (splitLine[0].equals("delete_u") && splitLine.length == 3) { // Delete_U

						String targetUName = splitLine[1];
						String targetULocation = splitLine[2];
						boolean successful = false;

						ps = con.prepareStatement("SELECT * FROM university WHERE UName = ? AND ULocation = ?");
						ps.setString(1, targetUName);
						ps.setString(2, targetULocation);
						ps.executeQuery();
						con.setAutoCommit(false);

						ResultSet rs = ps.getResultSet();
						while (rs.next()) {
							ps = con.prepareStatement("DELETE FROM uGrade WHERE UName = ? AND ULocation = ? ");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeUpdate();

							ps = con.prepareStatement("DELETE FROM major WHERE UName = ? AND ULocation = ? ");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeUpdate();

							ps = con.prepareStatement("DELETE FROM university WHERE UName = ? AND ULocation = ? ");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeUpdate();
							successful = true;

						}
						rs.close();
						if (successful) {
							System.out.println("Deletion of " + targetUName + " located at " + targetULocation
									+ " was successful.\n");
							con.commit();
							calculateRank();
						} else {
							System.out.println(targetUName + " located at " + targetULocation
									+ " does not exist in the database.\n");
							con.rollback();
						}
						con.setAutoCommit(true);

					} else if (splitLine[0].equals("delete_m") && splitLine.length == 4) {
						// Delete_M UName, Ulocation, major
						String targetUName = splitLine[1];
						String targetULocation = splitLine[2];
						String targetMajor = splitLine[3];

						boolean successful = false;

						ps = con.prepareStatement(
								"SELECT * FROM major WHERE UName = ? AND ULocation = ? AND majorTitle = ?");
						ps.setString(1, targetUName);
						ps.setString(2, targetULocation);
						ps.setString(3, targetMajor);
						ps.executeQuery();
						con.setAutoCommit(false);

						ResultSet rs = ps.getResultSet();
						while (rs.next()) {
							Statement stmt = con.createStatement();

							ps = con.prepareStatement("DELETE FROM major WHERE UName = ? AND ULocation = ? ");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeUpdate();

							successful = true;

						}
						rs.close();
						if (successful) {
							System.out.println(
									"Deletion of "+ targetMajor+ " from " + targetUName + " was successful.\n");
							con.commit();
						} else {
							System.out.println(" could not find " + targetMajor + " from " + targetUName + "\n");
							con.rollback();
						}
						con.setAutoCommit(true);

					} else if (splitLine[0].equals("delete_g") && splitLine.length == 3) {
						// Delete_g UName, Ulocation
						String targetUName = splitLine[1];
						String targetULocation = splitLine[2];

						boolean successful = false;

						ps = con.prepareStatement("SELECT * FROM uGrade WHERE UName = ? AND ULocation = ? ;");
						ps.setString(1, targetUName);
						ps.setString(2, targetULocation);
						ps.executeQuery();

						con.setAutoCommit(false);

						ResultSet rs = ps.getResultSet();
						while (rs.next()) {

							ps = con.prepareStatement("DELETE FROM uGrade WHERE UName = ? AND ULocation = ? ;");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeUpdate();

							ps = con.prepareStatement(
									"UPDATE university SET Rank = NULL WHERE UName = ? AND ULocation = ?;");
							ps.setString(1, targetUName);
							ps.setString(2, targetULocation);
							ps.executeUpdate();

							successful = true;
						}
						rs.close();
						if (successful) {
							System.out.println("Deletion successful.\n");
							con.commit();
							calculateRank();
						} else {
							System.out.println(" could not find school name " + targetUName + " located at "
									+ targetULocation + " from the grade table.\n");
							con.rollback();
						}
						con.setAutoCommit(true);

					} else if (splitLine[0].equals("edit_u") && splitLine.length == 5) {

						String TargetUName = splitLine[1];
						String TargetULocation = splitLine[2];
						String TargetAttribute = splitLine[3];
						String TargetValue = splitLine[4];

						if (TargetAttribute.equals("uname") || TargetAttribute.equals("ulocation")
								|| TargetAttribute.equals("rank")) {
							System.out
									.println("Invalid Input! Advisor can not touch Uname, ulocation, rank attributes!");
							continue;
						}

						con.setAutoCommit(false);
						ps = con.prepareStatement("SELECT ? FROM university WHERE UName = ? AND ULocation = ?;");
						ps.setString(1, TargetAttribute);
						ps.setString(2, TargetUName);
						ps.setString(3, TargetULocation);
						ps.executeQuery();

						ResultSet rs = ps.getResultSet();
						if (!rs.next()) {
							System.out.println("Invalid input! Check the uName and ULocation!");
							con.rollback();
							con.setAutoCommit(true);
						} else {
							ps = con.prepareStatement("UPDATE university SET " + TargetAttribute
									+ " = ? WHERE UName = ? AND ULocation = ?;");
							ps.setString(1, TargetValue);
							ps.setString(2, TargetUName);
							ps.setString(3, TargetULocation);
							try {
								ps.executeUpdate();
							} catch (Exception e) {
								System.out.println("invalid attribute");
								con.rollback();
								con.setAutoCommit(true);
								continue;
							}
							ps = con.prepareStatement("SELECT " + TargetAttribute
									+ " FROM university WHERE UName = ? AND ULocation = ?;");
							ps.setString(1, TargetUName);
							ps.setString(2, TargetULocation);
							try {
								ps.executeQuery();
							} catch (Exception e) {
								System.out.println("invalid attribute");
								con.rollback();
								con.setAutoCommit(true);
								continue;
							}
							rs = ps.getResultSet();
							rs.first();
							String outputValue = rs.getString(TargetAttribute);
							// System.out.println(outputValue + "\n" +
							// TargetValue);

							boolean valCorrect = true;
							if (TargetAttribute.equals("GRR") || (outputValue.length() != TargetValue.length())) {

								double d = Double.parseDouble(TargetValue);
								if (TargetValue.startsWith("-")) {
									System.out.println("Negative is not allowed ");
									valCorrect = false;
								} else if (d >= 0 && d <= 1) {
									TargetValue = TargetValue + ".0";
								} else {
									valCorrect = false;
									System.out.println(
											"invalid input, only enter floating numbers between 0 and 1 (inclusive)");
								}
							}
							if (TargetAttribute.equals("AAG") || (outputValue.length() != TargetValue.length())) {
								TargetValue = TargetValue + ".0";
								double d = Double.parseDouble(TargetValue);
								if (d >= 0 && d <= 4.5) {
									TargetValue = TargetValue + ".0";
								} else {
									valCorrect = false;
									System.out.println(
											"invalid input, only enter floating numbers between 0 and 1 (inclusive)");
								}
							}

							if (!outputValue.equals(TargetValue) || !valCorrect) {
								con.rollback();
								System.out.println("Error, check the value!");
							} else {
								con.commit();
								System.out.println("Update on university Success!");
							}
							con.setAutoCommit(true);
						}
					} else if (splitLine[0].equals("edit_m") && splitLine.length == 6) {
						String TargetUName = splitLine[1];
						String TargetULocation = splitLine[2];
						String TargetMajor = splitLine[3];
						String TargetAttribute = splitLine[4];
						int TargetValue = -1;

						if (TargetAttribute.equals("uname")
								|| TargetAttribute.equals("ulocation") && TargetAttribute.equals("majortitle")) {
							System.out.println(
									"Invalid Input! Advisor can not touch Uname, ulocation, majortitle attributes!");
							continue;
						}

						boolean typechk = false;
						if (splitLine[5].equals("t")) {
							typechk = true;
							TargetValue = 1;
						} else if (splitLine[5].equals("f")) {
							typechk = true;
							TargetValue = 0;
						} else
							System.out.println("Invaild Input ");

						if (typechk) {
							con.setAutoCommit(false);
							ps = con.prepareStatement(
									"SELECT ? FROM major WHERE UName = ? AND ULocation = ? AND majorTitle = ?;");
							ps.setString(1, TargetAttribute);
							ps.setString(2, TargetUName);
							ps.setString(3, TargetULocation);
							ps.setString(4, TargetMajor);
							ps.executeQuery();

							ResultSet rs = ps.getResultSet();
							if (!rs.next()) {
								System.out.println("Invalid input! Check the Uname or ULocation!");
								con.rollback();
								con.setAutoCommit(true);
							} else {
								ps = con.prepareStatement("UPDATE major SET " + TargetAttribute
										+ " = ? WHERE UName = ? AND ULocation = ? AND majorTitle = ?;");
								ps.setInt(1, TargetValue);
								ps.setString(2, TargetUName);
								ps.setString(3, TargetULocation);
								ps.setString(4, TargetMajor);
								try {
									ps.executeUpdate();
								} catch (Exception e) {
									System.out.println("invalid attribute");
									con.rollback();
									con.setAutoCommit(true);
									continue;
								}

								ps = con.prepareStatement("SELECT " + TargetAttribute
										+ " FROM major WHERE UName = ? AND ULocation = ? AND majorTitle = ?;");
								ps.setString(1, TargetUName);
								ps.setString(2, TargetULocation);
								ps.setString(3, TargetMajor);
								try {
									ps.executeQuery();
								} catch (Exception e) {
									System.out.println("invalid attribute");
									con.rollback();
									con.setAutoCommit(true);
									continue;
								}
								rs = ps.getResultSet();
								rs.first();
								int outputValue = rs.getInt(TargetAttribute);

								if (outputValue != TargetValue) {
									con.rollback();
									System.out.println("Error, check the value!");
								} else {
									con.commit();
									System.out.println("Update on major Success!");
								}
								con.setAutoCommit(true);
							}
						}
					} else if (splitLine[0].equals("edit_g") && splitLine.length == 5) {
						String TargetUName = splitLine[1];
						String TargetULocation = splitLine[2];
						String TargetAttribute = splitLine[3];
						String TargetValue = splitLine[4];
						if (!TargetValue.matches("((-|\\+)?[0-9]+(\\.[0-9]+)?)+")
								|| Double.parseDouble(TargetValue) > 10 || Double.parseDouble(TargetValue) < 0) {
							System.out.println("Invaild Input");
						} else {

							if (TargetAttribute.equals("uname") || TargetAttribute.equals("ulocation")
									|| TargetAttribute.equals("score")) {
								System.out.println(
										"Invalid Input! Advisor can not touch Uname, ulocation, score attributes!");
								continue;
							}
							con.setAutoCommit(false);
							ps = con.prepareStatement("SELECT ? FROM uGrade WHERE UName = ? AND ULocation = ?;");
							ps.setString(1, TargetAttribute);
							ps.setString(2, TargetUName);
							ps.setString(3, TargetULocation);
							ps.executeQuery();

							ResultSet rs = ps.getResultSet();
							if (!rs.first()) {
								System.out.println("Invalid input! Check the UName or ULocation !");
								con.rollback();
							} else {
								ps = con.prepareStatement("UPDATE uGrade SET " + TargetAttribute
										+ " = ? WHERE UName = ? AND ULocation = ?;");
								ps.setString(1, TargetValue);
								ps.setString(2, TargetUName);
								ps.setString(3, TargetULocation);
								try {
									ps.executeUpdate();
								} catch (Exception e) {
									System.out.println("invalid attribute");
									con.rollback();
									con.setAutoCommit(true);
									continue;
								}
								ps = con.prepareStatement("SELECT " + TargetAttribute
										+ " FROM uGrade WHERE UName = ? AND ULocation = ?;");
								ps.setString(1, TargetUName);
								ps.setString(2, TargetULocation);
								try {
									ps.executeQuery();
								} catch (Exception e) {
									System.out.println("invalid attribute");
									con.rollback();
									con.setAutoCommit(true);
									continue;
								}
								rs = ps.getResultSet();
								if (!rs.first()) {
									System.out.println("Invalid input! Check the UName or ULocation !");
									con.rollback();
									con.setAutoCommit(true);
									continue;
								}
								String outputValue = rs.getString(TargetAttribute);
								if (!outputValue.equals(TargetValue)) {
									System.out.println("Error, check the value!");
									con.rollback();
									con.setAutoCommit(true);
									continue;
								} else {
									ps = con.prepareStatement(
											"UPDATE uGrade SET score = GRR * 0.2 + EnteringClass * 0.15 + Faculty * 0.15 + Finance * 0.15 + graduate * 0.2 + environment * 0.15 "
													+ "WHERE UName = ? AND ULocation = ?");
									ps.setString(1, TargetUName);
									ps.setString(2, TargetULocation);
									try {
										ps.executeUpdate();
									} catch (Exception e) {
										System.out.println("Invalid input");
									}
									con.commit();
									calculateRank();
									System.out.println("Update on uGrade Success! \n");

								}
								con.setAutoCommit(true);
							}
						}

					} else if (splitLine[0].equals("createnewadmin") && splitLine.length == 3) {
						con.setAutoCommit(false);
						ps = con.prepareStatement("INSERT INTO admin (AdminCode, password) VALUES(?,?)");
						ps.setString(1, splitLine[1]);
						ps.setString(2, splitLine[2]);
						// ps.executeUpdate();
						try {
							ps.executeUpdate();
						} catch (Exception e) {
							System.out.println("invalid adminCode \n");
							con.rollback();
							con.setAutoCommit(true);
							continue;
						}

					} else if (splitLine[0].equals("quit")) {
						break;
					} else {
						System.out.println("Command syntax error ");
					}
				}

			}
		} catch (Exception e) {
			System.err.println("Exception: " + e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
	}

	public void calculateRank() throws SQLException {
		con.setAutoCommit(false);
		// read the Ugrade score
		ps = con.prepareStatement("SELECT * FROM uGrade Order by score DESC");
		try {
			ps.executeQuery();
		} catch (Exception e) {
			con.rollback();
			con.setAutoCommit(true);
			throw e;// terminate
		}
		int rankcur = 1;
		ResultSet rs = ps.getResultSet();
		while (rs.next()) {
			ps = con.prepareStatement("UPDATE university SET Rank = ? WHERE UName = ? AND ULocation = ?");
			ps.setInt(1, rankcur++);
			ps.setString(2, rs.getString("UName"));
			ps.setString(3, rs.getString("ULocation"));
			try {
				ps.executeUpdate();
			} catch (Exception e) {
				con.rollback();
				System.out.println("e update errorrrrrr");
				con.setAutoCommit(true);
				throw e;
			}
		}
	}

}
